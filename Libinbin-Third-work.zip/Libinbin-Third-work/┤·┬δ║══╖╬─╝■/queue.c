#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

void InitAQueue(AQueue *Q){
   Q->front = 0;
   Q->rear = 0;
   Q->data_size=10*sizeof(void *);
}

void DestoryAQueue(AQueue *Q){
    ClearAQueue(Q);
    free(Q);
    Q=NULL;
}

Status IsFullAQueue(const AQueue *Q){
    if(Q->front==(Q->rear+1)%MAXQUEUE)
        return TRUE;
    return FALSE;
}

Status IsEmptyAQueue(const AQueue *Q){
    if(Q->front == Q->rear){
        return TRUE;
    }
    return FALSE;
}

Status GetHeadAQueue(AQueue *Q, void **e){
    if(!IsEmptyAQueue(Q))
        *e=Q->data[Q->front];
    else
        return FALSE;
    return TRUE;
}

int LengthAQueue(AQueue *Q){
    int length= Q->rear - Q->front;
    if(length >= 0)
        return length;
    else
        return -length;
}

Status EnAQueue(AQueue *Q, void *data){
    if(!IsFullAQueue(Q)){//�����������������
        if(Q->rear==MAXQUEUE-1){//�������β������ѭ��
             Q->data[Q->rear]=data;
             Q->rear=0;
        }
        else
            Q->data[Q->rear++]=data;
    }
    else//������ԣ����ش���
        return FALSE;
    return TRUE;
}

Status DeAQueue(AQueue *Q){
    if(!IsEmptyAQueue(Q)){
        if(Q->front==MAXQUEUE-1)
            Q->front=0;
        else
            Q->front++;
    }
    else
        return FALSE;
    return TRUE;
}

void ClearAQueue(AQueue *Q){
    while(!IsEmptyAQueue(Q)){
        DeAQueue(Q);
    }
}

Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q)){
    int i=0,k=Q->front;
    for(i=Q->front;i!=Q->rear;i++){
            foo(Q->data[Q->front]);
            DeAQueue(Q);
    }
}

void APrint(void *q){
    printf("%d\n",*(int *)q);
}


//����Ϊ��ʽ����
void InitLQueue(LQueue *Q){
    Q->front=NULL;
    Q->rear=NULL;
    Q->data_size=0;
}

void DestoryLQueue(LQueue *Q){
    ClearLQueue(Q);
    free(Q);
    Q=NULL;
}


Status IsEmptyLQueue(const LQueue *Q){
    if(Q->front==NULL)
        return TRUE;
    return FALSE;
}

Status GetHeadLQueue(LQueue *Q, void **e){
    if(!IsEmptyLQueue(Q))
        *e=Q->front->data;
    else
        return FALSE;
    return TRUE;
}

int LengthLQueue(LQueue *Q){
    int i;
    Node *p=Q->front;
    for(i=0;p!=NULL;++i){
        p=p->next;
    }
    return i;
}

Status EnLQueue(LQueue *Q, void *data){
    Node *one = (Node *)malloc(sizeof(Node));
    one->data = data;
    one->next = NULL;
    if(Q->front==NULL){
        Q->front = one;
        Q->rear = one;
        Q->data_size+=sizeof(void *);
        return TRUE;
    }
    Q->rear->next = one;
    Q->rear=Q->rear->next;
    Q->data_size+=sizeof(void *);
    return TRUE;
}

Status DeLQueue(LQueue *Q){
    if(!IsEmptyLQueue(Q)){
    Node *a =Q->front;
    Q->front=Q->front->next;
    free(a);
     Q->data_size-=sizeof(void *);
    return TRUE;
    }
    return FALSE;
}

void ClearLQueue(LQueue *Q){
    while(Q->front!=NULL){
        Node *p=Q->front;
        Q->front=Q->front->next;
        free(p);
        p=NULL;
    }
    Q->front=NULL;
    Q->rear=NULL;
    Q->data_size=0;
}

Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q)){
    Node *p = Q->front;
    while(p!=NULL){
        foo(p->data);
        p=p->next;
    }
}

void LPrint(void *q){
    printf("%d\n",*(int *)q);
}

