package test3;


import java.io.*;
import java.net.Socket;
import java.util.Scanner;



/**
 * 接收客户端
 */
public class ReceiveClient extends Socket {

    private static final String SERVER_IP ="127.0.0.1";
    private static final int SERVER_PORT =10086;

    private Socket client;
    private DataInputStream dis;
    private FileOutputStream fos;
    String fileName;
    long fileLength;

    public ReceiveClient(){
        try {
            try {
                client =new Socket(SERVER_IP, SERVER_PORT);
                //向服务端传送文件
                int k=0;//控制错误输出后程序运行
                int i=1;//控制输出文件个数
                while(true) {
                    System.out.print("请输入第"+ i++ +"个文件储存路径：");
                    Scanner sc = new Scanner(System.in);
                    String fName = sc.nextLine();
                    if(fName.equalsIgnoreCase("byebye")){
                        System.out.println("结束");
                        break;
                    }
                    if(k==0) {
                        dis = new DataInputStream(client.getInputStream());
                        fileName = dis.readUTF();
                        fileLength = dis.readLong();
                    }
                    File file;
                    try {
                        file = new File(fName + "/" + fileName);
                        fos = new FileOutputStream(file);
                    }catch(Exception e){
                        System.out.println("文件路径错误，请重新输入");
                        k = 1;
                        --i;
                        continue;
                    }
                    k = 0;
                    System.out.println("----开始接收文件<" + fileName +">,文件大小为<" + fileLength +">----");
                    //文件名和长度
                    //传输文件
                    byte[] sendBytes = new byte[1024];
                    int length = 0;
                    int transLen = 0;
                    while ((length = dis.read(sendBytes, 0, sendBytes.length)) > 0) {
                        fos.write(sendBytes, 0, length);
                        fos.flush();
                        transLen += length;
                        System.out.println("接收文件进度" + 100 * transLen / fileLength + "%...");
                        if(transLen == fileLength){
                            break;
                        }
                    }
                    System.out.println("----接收文件<" + fileName + ">成功-------");
                }
            }catch (Exception e) {
                e.printStackTrace();
            }finally{
                if(fos !=null)
                    fos.close();
                if(dis !=null)
                    dis.close();
                client.close();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)throws Exception {
        new ReceiveClient();
    }
}
