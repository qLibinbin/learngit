package test3;


import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * 发送客户端
 */
public class SendClient extends Socket{

    private static final String SERVER_IP ="127.0.0.1";
    private static final int SERVER_PORT =10086;

    private Socket client;
    private FileInputStream fis;
    private DataOutputStream dos;

    public SendClient(){
        try {
            try {
                client =new Socket(SERVER_IP, SERVER_PORT);
                //向服务端传送文件
                int i = 1;
                while(true) {
                    System.out.print("请输入第" + i++ +"个文件传输文件路径：");
                    Scanner sc = new Scanner(System.in);
                    String fName = sc.nextLine();
                    if(fName.equalsIgnoreCase("byebye")){
                        System.out.println("结束");
                        break;
                    }
                    File file;
                    try {
                        file = new File(fName);
                        fis = new FileInputStream(file);
                    }catch(Exception e){
                        System.out.println("文件路径错误,请重新输入");
                        i--;
                        continue;
                    }

                    dos = new DataOutputStream(client.getOutputStream());

                    //文件名和长度
                    dos.writeUTF(file.getName());
                    dos.flush();
                    dos.writeLong(file.length());
                    dos.flush();

                    //传输文件
                    byte[] sendBytes = new byte[1024];
                    int length = 0;
                    while ((length = fis.read(sendBytes, 0, sendBytes.length)) > 0) {
                        dos.write(sendBytes, 0, length);
                        dos.flush();
                    }
                    System.out.println("文件成功发送到服务端");
                }
            }catch (Exception e) {
                e.printStackTrace();
            }finally{
                if(fis !=null)
                    fis.close();
                if(dos !=null)
                    dos.close();
                client.close();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)throws Exception {
        new SendClient();
    }
}