package test3;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 服务器
 */
public class Server extends ServerSocket {

    private static final int PORT = 10086;

    private ServerSocket server;
    private Socket client1, client2;
    private DataInputStream dis1;
    private DataOutputStream dos2;

    public Server() throws Exception {
        try {
            try {
                server = new ServerSocket(PORT);
                client1 = server.accept();
                System.out.println("发送客户端链接成功");
                client2 = server.accept();
                System.out.println("接收客户端链接成功");

                while (true) {
                    dis1 = new DataInputStream(client1.getInputStream());
                    //文件名和长度
                    dos2 = new DataOutputStream(client2.getOutputStream());
                    String fileName=null;
                    long fileLength=0;
                    try {
                        fileName = dis1.readUTF();
                        fileLength = dis1.readLong();
                    }catch(Exception e){
                        System.out.println("发送与接收客户端关闭,服务器关闭");
                        return ;
                    }

                    dos2.writeUTF(fileName);
                    dos2.writeLong(fileLength);

                    byte[] sendBytes = new byte[1024];
                    int transLen = 0;
                    System.out.println("----开始发送文件<" + fileName + ">,文件大小为<" + fileLength + ">----");
                    while (true) {
                        int read = 0;
                        read = dis1.read(sendBytes);
                        if (read == -1)
                            break;
                        transLen += read;

                        System.out.println("发送文件进度" + 100 * transLen / fileLength + "%...");
                        dos2.write(sendBytes, 0, read);
                        dos2.flush();

                        if (transLen == fileLength)
                            break;
                    }
                    System.out.println("----发送文件<" + fileName + ">成功-------");
                    //client1.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (dis1 != null)
                    dis1.close();
                server.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}