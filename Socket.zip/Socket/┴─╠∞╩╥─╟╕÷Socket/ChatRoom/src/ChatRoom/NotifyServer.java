package ChatRoom;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;

public class NotifyServer extends Thread{//负责开启线程控制
    Socket socket = null;
    InputStream in = null;
    HashMap<Integer, Socket> sessionMap = null;
    int index;//客户端编号

    public NotifyServer(Socket socket, HashMap<Integer, Socket> sessionMap,int index) {
        this.socket = socket;
        this.sessionMap = sessionMap;
        this.index = index;
    }

    public void run(){
        try{
            in = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(in);

            //一次连接多次发送消息
            Boolean flag = true;//标志第一次运行
            while (true){

                Message msg = null;
                try{
                    msg = (Message)ois.readObject();
                    msg.setId(index);
                }catch(SocketException e2){
                    System.out.println("客户端"+ index +"已退出");
                    break;
                }

                System.out.println("客户端"+index+"： " + msg.getMsg());

                //发送数据
                try{
                    for(int j = 1;j <= sessionMap.size();++j){
                        //如果第一次，不执行continue
                        if( j==index && !flag )
                            continue;
                        if(j==index)
                            flag = false;

                        Socket targetSocket = sessionMap.get(j);//得到一个Socket
                        OutputStream out = targetSocket.getOutputStream();
                        ObjectOutputStream oos;

                        try{
                            oos = new ObjectOutputStream(out);
                        }catch (Exception e){
                            continue;//如果某个客户端退出，不对他进行输出
                        }
                        oos.writeObject(msg);

                    }
                    System.out.println("服务端已转发");
                }catch (IOException e){
                    e.printStackTrace();
                }

                if(socket.isClosed()){
                    break;
                }
            }
        }catch (Exception e){

            try{
                socket.close();
            }catch (IOException e2){
                e.printStackTrace();
            }

        }
    }





}