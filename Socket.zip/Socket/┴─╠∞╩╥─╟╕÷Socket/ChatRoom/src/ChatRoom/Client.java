package ChatRoom;

import java.io.*;
import java.net.Socket;

public class Client {
    Socket socket = null;
    InputStreamReader input = null;//接受用户输入
    InputStream in = null;//接收服务端消息
    OutputStream out = null;//发送消息

    public void socketStart(){
        try{
            socket = new Socket("127.0.0.1", 10086);
            System.out.println("客户端启动.......");

            //开启线程接受服务端发送的数据
            new Thread(){
                public void run(){
                    try {
                        while(true){
                            in = socket.getInputStream();
                            ObjectInputStream ois = new ObjectInputStream(in);
                            Message msg = (Message)ois.readObject();
                            System.out.println("客户端" + msg.getId() + ": " + msg.getMsg());
                        }
                    }catch (Exception e){
                        System.out.println("服务端已关闭");
                        return;
                    }
                }
            }.start();

            //循环接受用户输入数据，并发送到服务端
            out = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(out);
            Boolean flag = true;//标记，第一次输出内容
            while(true){
                String msg;
                if(flag){
                    msg = "我登陆了";
                }else{
                    input = new InputStreamReader(System.in);
                    msg = new BufferedReader(input).readLine();
                }
                flag = false;
                Message message = new Message();
                message.setMsg(msg);
                oos.writeObject(message);
            }
        }catch(IOException e){
            System.out.println("输出信息失败");
            return;
        }finally {
            try{
                in.close();
                out.close();
                socket.close();
            }catch (Exception e1){
                e1.printStackTrace();
            }
        }
    }
    public static void main(String[] args){
        new Client().socketStart();
    }

}
