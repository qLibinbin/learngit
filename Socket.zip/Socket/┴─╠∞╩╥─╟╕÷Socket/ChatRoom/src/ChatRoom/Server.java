package ChatRoom;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class Server {
    //服务端
    ServerSocket serverSocket = null;
    //存放已链接客户端
    static HashMap<Integer,Socket> sessionMap = new HashMap<Integer,Socket>();

    public void socket(){
        try{
            serverSocket = new ServerSocket(10086);
            System.out.println("服务器开启......");
            int i=1;// 客户端编号

            //为每个客户端开启一个消息服务
            while(true){
                Socket socket = serverSocket.accept();
                System.out.println("客户端" + i + "连接成功。。。");
                if (socket != null) {
                    // 将socket放入map，key为客户端编号
                    sessionMap.put(i, socket);
                    // 开启线程处理本次会话
                    Thread thread = new Thread(new NotifyServer(socket, sessionMap,i));
                    thread.setDaemon(true);
                    thread.start();
                    i++;
                }
            }

        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException {
        new Server().socket();
    }
}
