## Socket的介绍
#### 第一个：FileTransfer
> 1. 里面有一个server类，一个sendclient类（用于发送文件，需要输入文件地址），一个ReceiveClient类（用于接受文件，需要输入储存地址）。
> 2. 启动时，先运行Server，再运行SendClient，最后运行ReceiveClient。在SendClient输入将传输文件路径，ReceiveClient输入储存路径。可以重复传输。在两个客户端输入“byebye”结束程序。
#### 第二个：ChatRoom
> 1. server类，启动服务端接监听客户端，一旦监听到客户端启动，new一个NotifyServer类，将客户端通道与客户端集合作为参数。
> 2. Client类，启动一个客户端，客户端启动一个线程，随时接收NotifyServer发送的消息，并在后面循环接收键盘输入消息，发送到NotifyServer。
> 3. NotifyServer类，负责监听该客户端的发送信息，并转发到其他客户端。

> 4. Message将消息与发送客户端编号绑定，用于传输。
> 5. 先启动服务端，然后启动任意多个客户端，在客户端打字，发消息就好。