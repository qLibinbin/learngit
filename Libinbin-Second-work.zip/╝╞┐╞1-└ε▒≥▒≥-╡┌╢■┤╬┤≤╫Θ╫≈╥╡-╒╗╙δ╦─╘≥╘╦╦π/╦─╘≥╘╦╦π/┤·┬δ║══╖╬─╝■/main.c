#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
int compare(char s[]);
int changeTo(char [],char []);
int isNumber(char);
int isOperator(char ch);
int degree(char ch);
int main(){
    char c=1;
    char str[100];
    char suffixExp[100];
    while(c!='#'){
    printf("����������ʽ��\n");
    gets(str);
    printf("%s\n",str);
    if(!compare(str)){//ƥ���ַ��������ţ���ƥ�䣬�ͽ���
       return 0;
    }

    printf("ת��Ϊ��׺����ʽ��\n");
    changeTo(str,suffixExp);
    printf("%s\n",suffixExp);

    printf("������Ϊ��%d\n",calculate(suffixExp));

    printf("����#��������,���������������С�\n�����룺");
    c=(char)getchar();
    getchar();
    }
    return 0;
}
int calculate(char SE[]){
    int i;
    LinkStack num;
    initLStack(&num);
    char data;//����������ջ
    int sum=0;//�洢���㣬���������
    for(i=0 ;SE[i]!='\0';++i){
        if(SE[i]==' ')
            continue;
        if(isNumber(SE[i])){
            data=(char)atoi(SE+i);
            pushLStack(&num,data);
            while(isNumber(SE[i]))
                ++i;
        }
        if(SE[i]==' ')
            continue;
        if(isOperator(SE[i])){
            char a,b;
            popLStack(&num,&a);
            popLStack(&num,&b);
            if(SE[i]=='+'){
                sum=(int)b+(int)a;
            }
            if(SE[i]=='-'){
                sum=(int)b-(int)a;
            }
            if(SE[i]=='*'){
                sum=(int)b*(int)a;
            }
            if(SE[i]=='/'){
                sum=(int)b/(int)a;
            }
            pushLStack(&num,(char)sum);
        }

    }
    char a=0;
    popLStack(&num,&a);
    sum=(int)a;
    return sum;

}
int turnChToInt(){

}
int isNumber(char ch){//����
    if(ch >= '0' && ch <= '9')
        return 1;
    else
        return 0;
}
int isOperator(char ch){//���ţ�+-*/(
    if(ch == '+')
        return 1;
    if(ch == '-')
        return 1;
    if(ch == '*')
        return 1;
    if(ch == '/')
        return 1;
    if(ch == '(')
        return 1;
    return 0;
}
int degree(char ch){
    if(ch == '+' || ch == '-')
        return 1;
    if(ch == '*' || ch == '/')
        return 2;
    return 0;
}
int changeTo(char str[],char SE[]){
    LinkStack op; //= (LinkStack *)malloc(sizeof(LinkStack));//��¼��������+-*/
    initLStack(&op);
    int i,j;
    int k=0;//����SE�����±�
    for(i=0;str[i]!='\0';++i){
        if(str[i]==' ')
            continue;

        if(isNumber(str[i])){//ɨ���������������֣�����һ��
            for(j=i;isNumber(str[j]);++j){
                SE[k++]=str[j];
            }
            SE[k++]=' ';
            i=j;
        }
        else
            j=i;

        if(str[j]==' ')
            {i=j;continue;}

        char top;
        getTopLStack(&op,&top);
        if((isOperator(str[j]) && (isEmptyStack(&op) || degree(str[j]) > degree(top))) || str[j]=='('){//�����ջ�����ȼ��󣬽�ջ����(��Ҳ��ջ
            if(str[j]=='(' && isOperator(str[j+1])){
                SE[k++]='0';
                SE[k++]=' ';
            }
            pushLStack(&op,str[j]);
            i=j;
            continue;
        }
        if( isOperator(str[j]) && degree(str[j]) <= degree(top) ){
            while( degree(str[j]) <= degree(top) && (top!='(') && !(isEmptyLStack(&op) )){
            popLStack(&op,&top);
            SE[k++]=top;
            getTopLStack(&op,&top);
            }
            char t=str[j];
            pushLStack(&op,str[j]);
            i=j;
            continue;
        }
        if( str[j]==')' ){
            getTopLStack(&op,&top);
            while(top!='('){
                SE[k++]=top;
                popLStack(&op,&top);
                getTopLStack(&op,&top);
            }
            popLStack(&op,&top);
            i=j;
            continue;
        }

    }
    char ch;
    while( !isEmptyLStack(&op) ){
        popLStack(&op,&ch);
        SE[k++]=ch;
    }
    SE[k++]='\0';

}
int compare(char s[]){//ƥ���ַ��������ţ���ƥ�䣬�ͽ���
    char ch;
    LinkStack *bkt = (LinkStack *)malloc(sizeof(LinkStack));//ȷ�������Ƿ�ƥ��
    initLStack(bkt);
    int i;
    for(i=0;s[i]!='\0';++i){
        if(s[i]=='('){
            pushLStack(bkt,s[i]);
            continue;
        }
        if(s[i]==')'){
           int k = popLStack(bkt,&ch);
           if(k == ERROR)
                {printf("���Ų�ƥ��\n");return 0;}
        }
    }
    if(!isEmptyLStack(bkt)){
        printf("���Ų�ƥ��\n");
        return 0;
    }
    printf("����ƥ��\n");

    return 1;

}
