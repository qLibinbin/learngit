#include <stdio.h>
#include <stdlib.h>
#include "sorting.h"
#include "stack.h"

void FindIndex(int *s,int left,int right,int index){
    static flag=0;
    if(flag==0)
        index--;
    flag++;

    if(left >= right){
        printf("��%dС������%d\n",index+1,*(s+left));
        return;
    }
    int i=left,j=right;
    int key=*(s+left);
    while(i<j){
        while( i<j && key <= *(s+j)){
            --j;
        }
        *(s+i)=*(s+j);
        while(i<j && key >= *(s+i)){
            ++i;
        }
        *(s+j)=*(s+i);
    }
    *(s+i)=key;
    if(index==i){
        printf("��%dС������%d\n",index+1,*(s+i));
        return;
    }
    if(index <= i-1)
        FindIndex(s,left,i-1,index);
    else
        FindIndex(s,i+1,right,index);
}
void ColorSort(int *s,int total){
    int *p1=s,*p2=s+total-1,*p=s;
    while(p<=p2){
        if(*p==2){
            int t=*p2;
            *p2=*p;
            *p=t;
            p++;
            p2--;
            continue;
        }
        if(*p==0){
            int t=*p1;
            *p1=*p;
            *p=t;
            p++;
            p1++;
            continue;
        }
        p++;
    }


}

void InsertSort(int *s,int total){//���뷨����
    int i,j,t;
    for(i=1; i < total;++i){
        t = *(s+i);
        j=i-1;
        while(j>=0 && *(s+j) > t){
           *(s+j+1)=*(s+j);
           j--;
        }
        *(s+j+1)=t;
    }
}

void MergeSort(int *s,int star,int end){//�鲢����
    int mid;
    if(star < end){
    mid = (star + end)/2;
    MergeSort(s,star,mid);//����
    MergeSort(s,mid+1,end);
    Merge(s,star,mid,end);//�鲢
    }
}
void Merge(int *s,int star,int mid,int end){//�鲢����
    int i=star,j=mid+1,k=0;
    int *t=(int *)malloc(sizeof(int)*(end-star+1));
    while(i < mid+1 && j < end+1){
        if(*(s+i) > *(s+j) ){
            *(t+k++)=*(s+j++);
        }
        else
            *(t+k++)=*(s+i++);
    }
    while(i < mid+1){
        *(t+k++)=*(s+i++);
    }
    while(j < end+1){
        *(t+k++)=*(s+j++);
    }
    for(i=star,k=0;i<=end;++i,++k)
        *(s+i)=*(t+k);
}


void QSort_Recursion(int *s,int left,int right){
    if(left >= right){
        return;
    }
    int i=left,j=right;
    int key=*(s+left);
    while(i<j){
        while( i<j && key <= *(s+j)){
            --j;
        }
        *(s+i)=*(s+j);
        while(i<j && key >= *(s+i)){
            ++i;
        }
        *(s+j)=*(s+i);
    }
    *(s+i)=key;
    QSort_Recursion(s,left,i-1);
    QSort_Recursion(s,i+1,right);
}

void QSort(int *s,int length){//���ŷǵݹ��
    int i=0,j=length-1;
    int key = *(s+i);
    LinkStack *ls=(LinkStack *)malloc(sizeof(LinkStack));
    initLStack(ls);

    pushLStack(ls,0);
    pushLStack(ls,length-1);

    while(!isEmptyLStack(ls)){
        int left,right;
        popLStack(ls,&right);//ȡ�������±�
        popLStack(ls,&left);
        i=left;
        j=right;
        key=*(s+left);
        if(i>=j){
            continue;
        }
        while(i<j){
            while( i<j && key <= *(s+j)){
                --j;
            }
            *(s+i)=*(s+j);
            while(i<j && key >= *(s+i)){
                ++i;
            }
            *(s+j)=*(s+i);
        }
        *(s+i)=key;
        pushLStack(ls,left);//�ֿ����Σ��ֱ���ջ
        pushLStack(ls,i-1);

        pushLStack(ls,i+1);
        pushLStack(ls,right);

    }
}

void CountSort(int *s,int range,int total){
    int *temp=(int *)malloc(sizeof(int)*total);//���ٵȴ�����鴢������
    int *cout=(int *)malloc(sizeof(int)*range);//�������飬Ϊ��Χ�����ּ���

    int i;
    for(i=0;i<range;++i){//��ʼ��
        *(cout+i) = 0;
    }

    for(i=0;i<total;++i){//ͳ�Ƹ���
        *(cout+*(s+i))+=1;
    }

    for(i=1;i<range;++i){//ͳ��ÿ����ǰ����
        *(cout+i) += *(cout+i-1);
    }

    for(i=total-1;i>=0;--i){
        *(temp+*(cout+*(s+i))-1)=*(s+i);
        *(cout+*(s+i))-=1;
    }

    for(i=0;i<total;++i){
        *(s+i)=*(temp+i);
    }

    free(temp);
    free(cout);
}

void RadixCountSort(int *s,int total){
    int cout[10];
    int i,j;
    int t=1;//���ڼ���λ����
    int *temp=(int *)malloc(sizeof(int)*total);

    for(j=0,t=1;j<3;++j,t*=10){

        for(i=0;i<10;++i){//����
            cout[i]=0;
        }

        for(i=0;i<total;++i){//����
            cout[*(s+i)/t%10]++;
        }

        for(i=1;i<10;++i){
            cout[i]+=cout[i-1];
        }

        for(i=total-1;i>=0;--i){
            *(temp+*(cout+ *(s+i)/t%10 )-1)=*(s+i);
            *(cout+*(s+i)/t%10)-=1;
        }

        for(i=0;i<total;++i){
            *(s+i)=*(temp+i);
        }
    }
}
