#ifndef SORTING_H_INCLUDED
#define SORTING_H_INCLUDED
void InsertSort(int *s,int total);
void MergeSort(int *s,int star,int end);
void Merge(int *s,int star,int mid,int end);
void QSort_Recursion(int *s,int left,int right);
void QSort(int *s,int length);
void CountSort(int *s,int range,int total);
void RadixCountSort(int *s,int total);
void ColorSort(int *s,int total);
#endif // SORTING_H_INCLUDED
