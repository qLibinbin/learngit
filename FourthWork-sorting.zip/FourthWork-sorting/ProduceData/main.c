#include <stdio.h>
#include <stdlib.h>


int main()
{
    FILE *tenThousand,*fiftyThousand,*twoHundredThousand;
    FILE *Hundred;
    tenThousand=fopen("10000.txt","w+");
    fiftyThousand=fopen("50000.txt","w+");
    twoHundredThousand=fopen("200000.txt","w+");
    Hundred=fopen("100.txt","w+");

    int s0[100],s1[10000],s2[50000],s3[200000];
    int i;
    char c[10];//��ʱ�洢

    //100������
    for(i=0;i<100;++i){
        s1[i]=rand()%100;
    }
    for(i=1;i<=100;++i){
        fputs(itoa(s1[i],c,10),Hundred);
        fputs("  ",Hundred);
        if(i%10==0)
            fputs("\r\n",Hundred);
    }

    //10000������
    for(i=0;i<10000;++i){
        s1[i]=rand()%100;
    }
    for(i=1;i<=10000;++i){
        fputs(itoa(s1[i],c,10),tenThousand);
        fputs("  ",tenThousand);
        if(i%100==0)
            fputs("\r\n",tenThousand);
    }

    //50000������
    for(i=0;i<50000;++i){
        s2[i]=rand()%100;
    }
    for(i=1;i<=50000;++i){
        fputs(itoa(s2[i],c,10),fiftyThousand);
        fputs("  ",fiftyThousand);
        if(i%100==0)
            fputs("\r\n",fiftyThousand);
    }

    //200000������
    for(i=0;i<200000;++i){
        s3[i]=rand()%100;
    }
    for(i=1;i<=200000;++i){
        fputs(itoa(s3[i],c,10),twoHundredThousand);
        fputs("  ",twoHundredThousand);
        if(i%100==0)
            fputs("\r\n",twoHundredThousand);
    }
}
