package com.example.pc.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by PC on 2018/5/12.
 */

public class ContactsDatabaseHelper extends SQLiteOpenHelper{//目前还没有用上
    public static final String CREATE_CONTACT="create table Contact("
            + "id integer primary key autoincrement, "
            + "name text, "
            + "number1 text, "
            + "number2 text, "
            + "imageId integer, "
            + "mygroup text)";
    private Context mContext;

    public ContactsDatabaseHelper(Context context, String name , SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_CONTACT);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
