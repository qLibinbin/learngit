package com.example.pc.server;

import android.content.Context;

import com.example.pc.db.IOMyContactsInfor;
import com.example.pc.po.Contacts;

import java.util.List;

/**
 * Created by PC on 2018/5/12.
 */

public class InforOperationMydb {//未开始使用
    private static InforOperationSys inforOperationSys;
    private Context context;
    private static List<Contacts> contactsList;
    private static IOMyContactsInfor ioMyContactsInfor;

    public InforOperationMydb(Context context){
        this.context=context;
        if(ioMyContactsInfor==null){
        ioMyContactsInfor = new IOMyContactsInfor(context);
        }
        if(inforOperationSys==null){
        inforOperationSys = new InforOperationSys(context);
        }
        if(contactsList==null){
        contactsList = ioMyContactsInfor.getContactList();
        }
    }

    public List<Contacts> getContactList(){
        return contactsList;
    }
    public void guideFromSys(){//从本地导入数据
        List<Contacts> contactsListSys = inforOperationSys.getContacts();
        for(int i=0;i<contactsListSys.size();++i){
            if(beIncluded(contactsListSys.get(i).getName(),contactsList)){
                continue;
            }
            else {
                contactsList.add(contactsListSys.get(i));
                addContact(contactsListSys.get(i));
            }
        }

    }
    private Boolean beIncluded(String name1,List<Contacts> contactsList2){
        if (contactsList2==null){
            return false;
        }
        for(int i=0;i<contactsList2.size();++i){
            if(name1.equals(contactsList2.get(i).getName()))
                return true;
        }
        return false;
    }
    public Boolean addContact(Contacts contacts){
        contactsList.add(contacts);
        ioMyContactsInfor.addContact(contacts);
        return true;
    }
    public Boolean deleteContact(String name){
        ioMyContactsInfor.deleteContact(name);
        for (int i=0;i<contactsList.size();++i){
            if(contactsList.get(i).getName().equals(name))
            {contactsList.remove(i); return true;}
        }
        return false;
    }
    public Boolean saveInfor(String name,Contacts oneContacts){
        ioMyContactsInfor.saveInfor(name,oneContacts);
        for (int i=0;i<contactsList.size();++i){
            if(contactsList.get(i).getName().equals(name)){
                contactsList.get(i).setName(oneContacts.getName());
                contactsList.get(i).setNumber(oneContacts.getNumber());
                contactsList.get(i).setGroup(oneContacts.getGroup());
                contactsList.get(i).setImageId(oneContacts.getImageId());
                return true;
            }
        }
        return false;
    }
}
