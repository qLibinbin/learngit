package com.example.pc.server;

import android.content.Context;

import com.example.pc.db.IOSystemContactInfor;
import com.example.pc.po.Contacts;

import java.util.List;

/**
 * Created by PC on 2018/5/10.
 */

public class InforOperationSys {
    private static List<Contacts> contactsList;
    private Context context;
    private static IOSystemContactInfor ioContactInfor;

    public InforOperationSys(Context context){
        this.context=context;
        if(ioContactInfor==null) {
            ioContactInfor = new IOSystemContactInfor(context);
        }
        if(contactsList==null){
            contactsList=ioContactInfor.getContactsList();
        }
    }
    public List<Contacts> getContacts(){
        return contactsList;
    }
    public Boolean saveInfor(String name,Contacts contacts){
        ioContactInfor.changeContact(name,contacts);
        for (int i=0;i<contactsList.size();++i){
            if(name.equals(name)){
                List<String> number=contacts.getNumber();
                contactsList.get(i).setNumber(number);
                contactsList.get(i).setName(contacts.getName());
                break;
            }
        }
        return true;
    }
    public Boolean addContact(Contacts contacts){
        contactsList.add(contacts);
        ioContactInfor.addContact(contacts);
        return true;
    }
    public Boolean deleteContact(String name){
        ioContactInfor.deleteContact(name);
        for (int i=0;i<contactsList.size();++i){
            if(name.equals(contactsList.get(i).getName())){
                contactsList.remove(i);
                return true;
            }
        }
        return false;
    }
}
