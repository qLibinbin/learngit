package com.example.pc.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.pc.adapter.ContactsAdapter;
import com.example.pc.po.Contacts;
import com.example.pc.server.InforOperationSys;
import com.example.pc.server.InforOperationMydb;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private DrawerLayout mDrawerLayout;
    private  List<Contacts> contactsList;
    private FloatingActionButton fabPlus;
    private InforOperationMydb inforOperationMydb;
    private ContactsAdapter adapter;



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//菜单
        getMenuInflater().inflate(R.menu.toolbar_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {//菜单功能
        switch (item.getItemId()){
            case R.id.guide:
                inforOperationMydb.guideFromSys();
                break;
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                break;
            default:
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //申请读取联系人权限
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_CONTACTS},1);}
        //申请写入联系人权限
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.WRITE_CONTACTS},2);}
        //申请打电话
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.CALL_PHONE},3);}

        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //界面与按钮
        mDrawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        NavigationView navView = (NavigationView)findViewById(R.id.nav_view) ;
        fabPlus = (FloatingActionButton)findViewById(R.id.fab_plus);
        ActionBar actionBar=getSupportActionBar();
        if(actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.p1);
        }

        //信息操作类，提供信息操作，增，删
        inforOperationMydb = new InforOperationMydb(this);
        //得到所有联系人
        //contactsList =  inforOperation.getContacts();
        contactsList = inforOperationMydb.getContactList();

        //利用继承ArrayAdapter的类和listview显示联系人姓名
        adapter = new ContactsAdapter(MainActivity.this,R.layout.contacts_item, contactsList);
        ListView listView = (ListView)findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        fabPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,InforActivity.class);
                intent.putExtra("isAdd",true);
                startActivity(intent);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Contacts oneContact = contactsList.get(position);
                Intent intent = new Intent(MainActivity.this,InforActivity.class);

                intent.putExtra("contact",oneContact);
                intent.putExtra("isAdd",false);
                startActivity(intent);
            }
        });

        navView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_back:mDrawerLayout.closeDrawers();
                                        MainActivity.this.finish();
                                        break;
                    default:
                }
                return true;
            }
        });




    }
    @Override
    public void onClick(View v) {
        if(v==null)
            Toast.makeText(this,"该联系人不存在",Toast.LENGTH_SHORT).show();
        adapter.notifyDataSetChanged();
    }


}
