package com.example.pc.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pc.po.Contacts;
import com.example.pc.server.InforOperationMydb;
import com.example.pc.server.InforOperationSys;

import java.util.ArrayList;
import java.util.List;

public class InforActivity extends AppCompatActivity {
    private Boolean isAdd;//判断打开的界面
    private EditText nameEdit,numberEdit;
    private Button delete;
    private InforOperationMydb inforOperationMydb;
    private Contacts contacts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infor);

        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbarInfor);
        setSupportActionBar(toolbar);

        inforOperationMydb = new InforOperationMydb(InforActivity.this);

        ActionBar actionBar=getSupportActionBar();
        if(actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        final Intent intent=getIntent();

        isAdd = intent.getBooleanExtra("isAdd",true);
        nameEdit=(EditText)findViewById(R.id.name_Edit);
        numberEdit=(EditText)findViewById(R.id.number_Edit);
        if(!isAdd) {
            contacts=(Contacts) intent.getSerializableExtra("contact");
            nameEdit.setText(contacts.getName());
            numberEdit.setText(contacts.getNumber().get(0));
        }

        delete= (Button)findViewById(R.id.infor_delete) ;
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inforOperationMydb.deleteContact(nameEdit.getText().toString());
                Toast.makeText(InforActivity.this,"删除"+nameEdit.getText().toString()+"成功",Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void saveInfor(){

        List<String> number = new ArrayList<>();
        number.add( numberEdit.getText().toString() );
        if(isAdd){//增加
            Contacts oneContacts = new Contacts(nameEdit.getText().toString(),number);
            if(inforOperationMydb.addContact(oneContacts)){
                Toast.makeText(InforActivity.this,"添加"+nameEdit.getText().toString()+"成功",Toast.LENGTH_SHORT).show();
                InforActivity.this.finish();
            }
        }
        else{//保存修改
            Contacts oneContacts = new Contacts(nameEdit.getText().toString(),number);
            inforOperationMydb.saveInfor(contacts.getName(),oneContacts);
            Toast.makeText(InforActivity.this,"保存成功",Toast.LENGTH_SHORT).show();
            InforActivity.this.finish();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.infor_toolbar_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
            case R.id.call:
                if (ContextCompat.checkSelfPermission(InforActivity.this,
                        Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(InforActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},3);}
                Intent intent1 = new Intent(Intent.ACTION_CALL);
                intent1.setData(Uri.parse("tel:"+contacts.getNumber().get(0)));
                startActivity(intent1);
                break;
            case R.id.sent_message:
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + contacts.getNumber().get(0)));
                startActivity(intent);
                break;
            case R.id.save:
                saveInfor();
                break;
            default:
        }
        return true;
    }


}
