package com.example.pc.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.pc.po.Contacts;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PC on 2018/5/12.
 */

public class IOMyContactsInfor {
    private Context context;
    private static ContactsDatabaseHelper dbHelper;
    private static List<Contacts> contactsList;
    private static SQLiteDatabase db;

    public IOMyContactsInfor(Context context){
        this.context=context;
        if(dbHelper==null)
            dbHelper = new ContactsDatabaseHelper(context,"ContactsData.db",null,1);
        if(db==null)
            db=dbHelper.getWritableDatabase();
        if (contactsList==null)
        readContacts();//读取所以联系人信息，到contactsList
    }
    public void addContact(Contacts contacts){
        ContentValues values = new ContentValues();
        //组装数据
        values.put("name",contacts.getName());
        values.put("number1",contacts.getNumber().get(0));
        if(contacts.getNumber().size()>1)
            values.put("number2",contacts.getNumber().get(1));
        values.put("imageId",contacts.getImageId());
        values.put("mygroup",contacts.getGroup());
        db.insert("Contact",null,values);
    }
    public List<Contacts> getContactList(){
        return contactsList;
    }
    private void readContacts(){
        Cursor cursor = db.query("Contact",null,null,null,null,null,null);
        contactsList = new ArrayList<Contacts>();
        if(cursor.moveToFirst()){
            do {
                String name=cursor.getString(cursor.getColumnIndex("name"));
                String number1=cursor.getString(cursor.getColumnIndex("number1"));
                String number2=cursor.getString(cursor.getColumnIndex("number2"));
                int imageId=cursor.getInt(cursor.getColumnIndex("imageId"));
                String mygroup=cursor.getString(cursor.getColumnIndex("mygroup"));

                List<String> number=new ArrayList<>();
                number.add(number1);
                number.add(number2);

                contactsList.add(new Contacts(name,imageId,number,mygroup));

            }while (cursor.moveToNext());
            cursor.close();
        }
    }
    public Boolean deleteContact(String name){
        db.delete("Contact","name = ?",new String[]{name});
        return true;
    }
    public Boolean saveInfor(String name,Contacts oneContacts){
        ContentValues values=new ContentValues();
        values.put("name",oneContacts.getName());
        values.put("number1",oneContacts.getNumber().get(0));
        if(oneContacts.getNumber().size()>1)
            values.put("number2",oneContacts.getNumber().get(1));
        values.put("imageId",oneContacts.getImageId());
        values.put("mygroup",oneContacts.getGroup());
        db.update("Contact",values,"name = ?",new String[]{name});
        return true;

    }
}
