package com.example.pc.addressbook;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import com.example.pc.po.Contacts;
import com.example.pc.server.InforOperation;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //申请读取联系人权限
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_CONTACTS},1);}
        //申请写入联系人权限
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_CONTACTS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.WRITE_CONTACTS},2);}
        //申请打电话
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.CALL_PHONE},3);}

        //信息操作类，提供信息操作，增，删
        final InforOperation inforOperation = new InforOperation(this);
        //得到所有联系人
        final List<Contacts> contactsList;
        contactsList =  inforOperation.getContacts();

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null){//隐藏标题栏
            actionBar.hide();
        }
        //利用继承ArrayAdapter的类和listview显示联系人姓名
        ContactsAdapter adapter = new ContactsAdapter(MainActivity.this,R.layout.contacts_item, contactsList);
        ListView listView = (ListView)findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Contacts oneContact = contactsList.get(position);
                Intent intent = new Intent(MainActivity.this,InforActivity.class);
                intent.putExtra("name",oneContact.getName());
                intent.putExtra("number1",oneContact.getNumber().get(0));
                intent.putExtra("isAdd",false);
                startActivity(intent);
            }
        });

        Button add = (Button)findViewById(R.id.title_edit);
        add.setText("新建联系人");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,InforActivity.class);
                intent.putExtra("isAdd",true);
                startActivity(intent);
            }
        });
    }
}

