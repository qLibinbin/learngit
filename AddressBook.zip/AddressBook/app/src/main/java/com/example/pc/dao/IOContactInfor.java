package com.example.pc.dao;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import android.widget.Toast;

import com.example.pc.po.Contacts;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by PC on 2018/5/9.
 */

public class IOContactInfor {
    Context context;
    List<Contacts> contactsList;
    public IOContactInfor(Context context){
        this.context=context;
        this.contactsList=new ArrayList<>();
        readContacts(context);
    }
    public List<Contacts> getContactsList(){
        return contactsList;
    }

    public void addContact(Contacts contacts){
        Uri uri = Uri.parse("content://com.android.contacts/raw_contacts");
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        long contactId = ContentUris.parseId(resolver.insert(uri, values));
        /* 往 data 中添加数据（要根据前面获取的id号） */
        // 添加姓名
        uri = Uri.parse("content://com.android.contacts/data");
        values.put(ContactsContract.Data.RAW_CONTACT_ID,contactId);
        values.put(ContactsContract.Data.MIMETYPE, "vnd.android.cursor.item/name");
        values.put(ContactsContract.Data.DATA2, contacts.getName());
        resolver.insert(uri, values);
        // 添加电话
        values.clear();
        values.put(ContactsContract.Data.RAW_CONTACT_ID, contactId);
        values.put(ContactsContract.Data.MIMETYPE, "vnd.android.cursor.item/phone_v2");
        values.put(ContactsContract.Data.DATA2,"2");
        values.put(ContactsContract.Data.DATA1, contacts.getNumber().get(0));
        resolver.insert(uri, values);

    }
    public void changeContact(String name,Contacts contacts){
        deleteContact(name);
        addContact(contacts);
    }
    public void deleteContact(String name){

        Uri uri = ContactsContract.RawContacts.CONTENT_URI;
        ContentResolver resolver = context.getContentResolver();
        String where = ContactsContract.PhoneLookup.DISPLAY_NAME;
        Cursor cursor = resolver.query(uri, new String[]{ContactsContract.Data._ID}, where + "=?", new String[]{name}, null);
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);

            //根据id删除data中的相应数据
            resolver.delete(uri, where + "=?", new String[]{name});
            uri = ContactsContract.Data.CONTENT_URI;
            resolver.delete(uri, ContactsContract.Data.RAW_CONTACT_ID + "=?", new String[]{id + ""});
        }
        Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        cursor.close();

    }
    private void readContacts(Context context) {
        Cursor cursor = null;
        try {//获取所有联系人
            cursor = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                    null, null, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    Contacts oneContacts;
                    List<String> numbers = new ArrayList<>();
                    //得到一个联系人和他所有号码
                    String displayName = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                    String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    numbers.add(number);
                    //getAllPhone(context,cursor,displayName,numbers);
                    //增加联系人
                    oneContacts=new Contacts(displayName,numbers);
                    contactsList.add(oneContacts);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null)
                cursor.close();
        }

    }

    private void getAllPhone(Context context, Cursor cursor, String displayName,List<String> numbers) {
        // 查看联系人有多少个号码，如果没有号码，返回0
        int phoneCount = cursor
                .getInt(cursor
                        .getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

        if (phoneCount > 0) {
            // 获得联系人的电话号码列表
            Cursor phoneCursor = context.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                            + "=" + displayName, null, null);
            if (phoneCursor.moveToFirst()) {
                do {
                    //遍历所有的联系人下面所有的电话号码
                    String phoneNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    numbers.add(phoneNumber);
                } while (phoneCursor.moveToNext());
            }
        }
    }
}