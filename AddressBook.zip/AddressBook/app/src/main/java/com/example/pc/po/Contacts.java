package com.example.pc.po;

import java.util.List;

/**
 * Created by PC on 2018/5/9.
 */

public class Contacts {
    private String name;
    private int imageId;
    private List<String> numbers;
    private String group;

    public Contacts(String name,List<String> numbers){
        this(name,-1,numbers,null);
    }
    public Contacts(String name,int imageId,List<String> numbers,String group) {
        this.name=name;
        this.imageId=imageId;
        this.numbers=numbers;
        this.group=group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
    public void setNumber(List<String> numbers) {
        this.numbers = numbers;
    }
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getGroup() {
        return group;
    }
    public List<String> getNumber() {
        return numbers;
    }
    public int getImageId() {
        return imageId;
    }
    public String getName() {
        return name;
    }
}
