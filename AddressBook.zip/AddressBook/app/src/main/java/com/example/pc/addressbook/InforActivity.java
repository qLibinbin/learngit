package com.example.pc.addressbook;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pc.po.Contacts;
import com.example.pc.server.InforOperation;

import java.util.ArrayList;
import java.util.List;

public class InforActivity extends AppCompatActivity {
    String name;//联系人姓名和号码
    String number1;
    Boolean isAdd;//判断打开的界面
    Button delete;//界面删除按钮
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infor);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null){
            actionBar.hide();
        }

        final Intent intent=getIntent();
        name=intent.getStringExtra("name");
        number1=intent.getStringExtra("number1");
        isAdd = intent.getBooleanExtra("isAdd",true);
        final EditText nameEdit=(EditText)findViewById(R.id.name_Edit);
        final EditText numberEdit=(EditText)findViewById(R.id.number_Edit);
        nameEdit.setText(name);
        numberEdit.setText(number1);

        //按键修改，监听
        Button save = (Button)findViewById(R.id.title_edit);
        save.setText("保存");
        delete = (Button) findViewById(R.id.infor_delete);
        if(isAdd) {
            delete.setVisibility(View.INVISIBLE);
        }
        Button call=(Button)findViewById(R.id.call) ;
        Button message =(Button)findViewById(R.id.send_message);


        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //申请打电话
                if (ContextCompat.checkSelfPermission(InforActivity.this,
                        Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(InforActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},3);}
                Intent intent1 = new Intent(Intent.ACTION_CALL);
                intent1.setData(Uri.parse("tel:"+number1));
                startActivity(intent1);
            }
        });

        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + number1));
                startActivity(intent);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InforOperation inforOperation = new InforOperation(InforActivity.this);

                List<String> number = new ArrayList<>();
                number.add( numberEdit.getText().toString() );
                if(isAdd){//增加
                    Contacts oneContacts = new Contacts(nameEdit.getText().toString(),number);
                    if(inforOperation.addContact(oneContacts)){
                        Toast.makeText(InforActivity.this,"添加"+nameEdit.getText().toString()+"成功",Toast.LENGTH_SHORT).show();
                        InforActivity.this.finish();
                    }
                }
                else{//保存修改
                    Contacts oneContacts = new Contacts(nameEdit.getText().toString(),number);
                    inforOperation.saveInfor(name,oneContacts);
                    Toast.makeText(InforActivity.this,"保存成功",Toast.LENGTH_SHORT).show();
                    InforActivity.this.finish();
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InforOperation inforOperation = new InforOperation(InforActivity.this);
                inforOperation.deleteContact(name);
                Toast.makeText(InforActivity.this,"删除成功",Toast.LENGTH_SHORT).show();
                InforActivity.this.finish();
            }
        });
    }
}
